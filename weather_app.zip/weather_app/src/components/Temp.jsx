import React from 'react'

function Temp({temp}) {
  return (
    <div className="temp">{temp}°C</div>
  )
}

export default Temp