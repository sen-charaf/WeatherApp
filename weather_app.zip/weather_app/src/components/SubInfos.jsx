import React from 'react'
import Humidity from './Humidity'
import WindSpeed from './WindSpeed'

function SubInfos({humidity,windSpeed}) {
  return (
    <div className="sub-infos">
          <Humidity
           humidity={humidity}
           />
          <WindSpeed
          windSpeed={windSpeed}
          />
    </div>
  )
}

export default SubInfos