import React from 'react'

function SearchBar({text,setText}) {
  return (
    <input type="text" name="search" id="idsearch" placeholder='Enter city name' 
    value={text}
    onChange={(e)=>setText(e.target.value)}
    />
  )
}

export default SearchBar