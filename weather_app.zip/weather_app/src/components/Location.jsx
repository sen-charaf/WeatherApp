import React from 'react'

function Location({displayedName}) {
  return (
    <div className="location">{displayedName}</div>
  )
}

export default Location