import React, { useEffect, useState } from 'react'
import TopSection from './TopSection'
import BotSection from './BotSection'
import axios from 'axios'

function Container() {
  const [cityName,setCityName]=useState("agadir");
  const [displayedName,setDisplayedName]=useState("");  
  const [humidity,setHumidity]=useState("");
  const [temp,setTemp]=useState("");
  const [windSpeed,setWindSpeed]=useState("")
  const [wallpaper,setWallpaper]=useState("")

  const wallpaperHandler=()=>{
    if (temp >= 20)  setWallpaper("warm");
    else if (temp >= 10)  setWallpaper("mid");
    else if (temp >= 0)  setWallpaper("cold")
    else  setWallpaper("freez");
  }

  useEffect(()=>{
    const key='04590c70304ff9ee6b4a6ae236e08f7b';
    axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${cityName}&appid=${key}&units=metric`)
      .then(response => {
        console.log(response.data);
        setDisplayedName(response.data.name);
        setHumidity(response.data.main.humidity);
        setTemp(response.data.main.temp);
        setWindSpeed(response.data.wind.speed);
      })
      .catch(error=>console.log(error.message));
  },[cityName])

  useEffect(()=>{
    wallpaperHandler();
  },[temp]);

  return (
    <div className={`main-container ${wallpaper}`}>
        <TopSection 
        setCityName={setCityName}
        />
        <BotSection
        displayedName={displayedName}
        humidity={humidity}
        temp={temp}
        windSpeed={windSpeed}
        />
    </div>
  )
}

export default Container