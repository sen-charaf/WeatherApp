import React from 'react'
import Location from './Location'
import Temp from './Temp'


function MainInfos({displayedName,temp}) {
  return (
    <div className="main-infos">
          <Location
           displayedName={displayedName}
           />
          <Temp
          temp={temp}
          />
    </div>
  )
}

export default MainInfos