import React, { useState } from 'react'
import SearchBar from './SearchBar'
import FindButton from './FindButton'

function TopSection({setCityName}) {
  const [text,setText]=useState("")

  return (
    <div className="top-section">
          <SearchBar
          text={text}
          setText={setText}
          />
          <FindButton
          text={text}
          setCityName={setCityName}
          />
    </div>
  )
}

export default TopSection