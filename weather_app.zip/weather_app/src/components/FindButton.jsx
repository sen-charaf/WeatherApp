import React, { useState } from 'react'

function FindButton({text,setCityName}) {
  const [icon,setIcon]=useState(`src/image/icons8-search-white(1).png`)
  return (
    <button className='submit-button' 
    onClick={()=>setCityName(text)} 
    onMouseEnter={()=>setIcon(`src/image/icons8-search-black.png`)}
    onMouseLeave={()=>setIcon(`src/image/icons8-search-white(1).png`)}
    >
      <img className='searchimg' 
      src={icon} 
      alt="search_button" />
      </button>
  )
}

export default FindButton