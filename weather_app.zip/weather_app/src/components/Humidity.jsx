import React from 'react'

function Humidity({humidity}) {
  return (
    <div className="humidity">
      <img className='icon' src="src\image\humidityicon.png" alt="humidity-icon" />
      {humidity}%
      </div>
  )
}

export default Humidity