import React from 'react'

function WindSpeed({windSpeed}) {
  return (
    <div className="windspeed">
      <img className='icon' src="src\image\winds-weather-symbol.png" alt="windicon" />
      {windSpeed} m/s</div>
  )
}

export default WindSpeed