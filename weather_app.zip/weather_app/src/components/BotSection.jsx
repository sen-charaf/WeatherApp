import React from 'react'
import MainInfos from './MainInfos'
import SubInfos from './SubInfos'

function BotSection({displayedName,humidity,temp,windSpeed}) {
  return (
    <div className="bot-section">
        <MainInfos
        displayedName={displayedName}
        temp={temp}
        />
        <SubInfos
         humidity={humidity}
         windSpeed={windSpeed}
         />
    </div>
  )
}

export default BotSection